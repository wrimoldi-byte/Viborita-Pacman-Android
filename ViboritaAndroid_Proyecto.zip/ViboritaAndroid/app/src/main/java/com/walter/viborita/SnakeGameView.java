package com.walter.viborita;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SnakeGameView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Point> snake = new ArrayList<>();
    private final Random random = new Random();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final int cols = 18;
    private final int rows = 28;
    private Point food = new Point(12, 10);
    private int dx = 1, dy = 0;
    private int nextDx = 1, nextDy = 0;
    private int score = 0;
    private boolean gameOver = false;
    private float downX, downY;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            updateGame();
            invalidate();
            handler.postDelayed(this, Math.max(75, 165 - score * 3L));
        }
    };

    public SnakeGameView(Context context) {
        super(context);
        setBackgroundColor(Color.rgb(15, 23, 42));
        resetGame();
        handler.postDelayed(tick, 300);
    }

    private void resetGame() {
        snake.clear();
        snake.add(new Point(7, 14));
        snake.add(new Point(6, 14));
        snake.add(new Point(5, 14));
        dx = nextDx = 1;
        dy = nextDy = 0;
        score = 0;
        gameOver = false;
        spawnFood();
    }

    private void updateGame() {
        if (gameOver) return;
        dx = nextDx;
        dy = nextDy;
        Point head = snake.get(0);
        int nx = (head.x + dx + cols) % cols;
        int ny = (head.y + dy + rows) % rows;

        for (Point p : snake) {
            if (p.x == nx && p.y == ny) {
                gameOver = true;
                return;
            }
        }

        snake.add(0, new Point(nx, ny));
        if (nx == food.x && ny == food.y) {
            score++;
            spawnFood();
        } else {
            snake.remove(snake.size() - 1);
        }
    }

    private void spawnFood() {
        boolean valid;
        do {
            food = new Point(random.nextInt(cols), random.nextInt(rows));
            valid = true;
            for (Point p : snake) {
                if (p.equals(food)) { valid = false; break; }
            }
        } while (!valid);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float top = 115f;
        float cell = Math.min(getWidth() / (float) cols,
                (getHeight() - top - 40f) / rows);
        float boardW = cell * cols;
        float left = (getWidth() - boardW) / 2f;

        paint.setColor(Color.WHITE);
        paint.setTextSize(48f);
        paint.setFakeBoldText(true);
        canvas.drawText("VIBORITA", 24f, 55f, paint);
        paint.setTextSize(30f);
        paint.setFakeBoldText(false);
        canvas.drawText("Puntos: " + score, 24f, 95f, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(30, 41, 59));
        canvas.drawRoundRect(new RectF(left - 5, top - 5, left + boardW + 5,
                top + rows * cell + 5), 20, 20, paint);

        paint.setColor(Color.rgb(239, 68, 68));
        float fx = left + food.x * cell;
        float fy = top + food.y * cell;
        canvas.drawCircle(fx + cell / 2, fy + cell / 2, cell * 0.34f, paint);
        paint.setColor(Color.rgb(34, 197, 94));
        canvas.drawOval(new RectF(fx + cell * .48f, fy + cell * .06f,
                fx + cell * .8f, fy + cell * .3f), paint);

        for (int i = snake.size() - 1; i >= 0; i--) {
            Point p = snake.get(i);
            float x = left + p.x * cell;
            float y = top + p.y * cell;
            paint.setColor(i == 0 ? Color.rgb(74, 222, 128) : Color.rgb(34, 197, 94));
            canvas.drawRoundRect(new RectF(x + 2, y + 2, x + cell - 2, y + cell - 2),
                    cell * .28f, cell * .28f, paint);
            if (i == 0) drawFace(canvas, x, y, cell);
        }

        if (gameOver) {
            paint.setColor(Color.argb(210, 0, 0, 0));
            canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setFakeBoldText(true);
            paint.setTextSize(56f);
            canvas.drawText("¡Perdiste!", getWidth()/2f, getHeight()/2f - 30, paint);
            paint.setTextSize(30f);
            paint.setFakeBoldText(false);
            canvas.drawText("Tocá para volver a jugar", getWidth()/2f, getHeight()/2f + 30, paint);
            paint.setTextAlign(Paint.Align.LEFT);
        }
    }

    private void drawFace(Canvas canvas, float x, float y, float cell) {
        paint.setColor(Color.BLACK);
        canvas.drawCircle(x + cell * .32f, y + cell * .35f, cell * .07f, paint);
        canvas.drawCircle(x + cell * .68f, y + cell * .35f, cell * .07f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(3, cell * .07f));
        canvas.drawArc(new RectF(x + cell * .28f, y + cell * .35f,
                x + cell * .72f, y + cell * .78f), 15, 150, false, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            downX = event.getX();
            downY = event.getY();
            if (gameOver) { resetGame(); invalidate(); }
            return true;
        }
        if (event.getAction() == MotionEvent.ACTION_UP) {
            float sx = event.getX() - downX;
            float sy = event.getY() - downY;
            if (Math.abs(sx) < 25 && Math.abs(sy) < 25) return true;
            if (Math.abs(sx) > Math.abs(sy)) {
                if (sx > 0 && dx != -1) { nextDx = 1; nextDy = 0; }
                else if (sx < 0 && dx != 1) { nextDx = -1; nextDy = 0; }
            } else {
                if (sy > 0 && dy != -1) { nextDx = 0; nextDy = 1; }
                else if (sy < 0 && dy != 1) { nextDx = 0; nextDy = -1; }
            }
            return true;
        }
        return true;
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacks(tick);
        super.onDetachedFromWindow();
    }
}
