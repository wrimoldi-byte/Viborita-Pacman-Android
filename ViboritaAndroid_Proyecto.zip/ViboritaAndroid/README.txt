VIBORITA ANDROID

Juego simple de viborita para Android.
- Deslizá el dedo para cambiar de dirección.
- La viborita atraviesa los bordes y aparece del otro lado.
- Come manzanas y crece.
- Tocá la pantalla para reiniciar al perder.
- No utiliza internet ni permisos especiales.

COMPILAR EN ANDROID STUDIO
1. Abrí Android Studio.
2. Elegí Open y seleccioná la carpeta ViboritaAndroid.
3. Esperá que termine la sincronización de Gradle.
4. Build > Build APK(s).
5. El APK aparecerá en app/build/outputs/apk/debug/app-debug.apk.
